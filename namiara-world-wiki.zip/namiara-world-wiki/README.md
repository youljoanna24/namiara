# 나미아라 가문 기록 보관소

개인 창작 세계관을 정리하기 위한 정적 위키입니다. GitHub Pages에 그대로 배포할 수 있습니다.

## GitHub Pages 배포
1. GitHub에서 새 저장소(repository)를 만듭니다.
2. 이 폴더 안의 파일과 폴더를 저장소 최상위에 업로드합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Build and deployment**에서 `Deploy from a branch`를 선택합니다.
5. Branch는 `main`, 폴더는 `/ (root)`로 선택하고 저장합니다.
6. 잠시 기다리면 Pages 주소가 생성됩니다.

## 설정 수정
- 홈: `index.html`
- 공통 디자인: `assets/style.css`
- 메뉴 동작 및 인물 검색: `assets/main.js`
- 세계관: `world/index.html`
- 인물 목록: `characters/index.html`
- 개별 인물: `characters/*.html`
- 연표: `timeline/index.html`

새 인물을 추가하려면 `characters` 폴더에 기존 인물 HTML을 복사해 새 파일을 만들고, `characters/index.html`에 카드 링크를 추가하면 됩니다.

## 주의
현재 문서는 대화에서 확인된 나미아라 가문 설정을 바탕으로 만든 초안입니다. 확정되지 않은 연도나 세부 설정은 임의로 채우지 않았습니다.
